﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CarToGo.Migrations
{
    /// <inheritdoc />
    public partial class BrandNew : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
